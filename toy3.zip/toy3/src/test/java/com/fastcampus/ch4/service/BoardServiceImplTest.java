package com.fastcampus.ch4.service;

import org.junit.*;

import java.time.*;

import static org.junit.Assert.*;

public class BoardServiceImplTest {

    @Test
    public void read() {
    }

    @Test
    public void edit() {
    }

    @Test
    public void write() {
    }

    @Test
    public void remove() {
    }

    @Test
    public void getPage() {
    }

    @Test
    public void getList() {
    }
}