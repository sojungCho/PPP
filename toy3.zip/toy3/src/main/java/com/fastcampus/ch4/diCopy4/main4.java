//package com.fastcampus.ch3.diCopy4;
//
//
//import com.google.common.reflect.ClassPath;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StringUtils;
//
//import javax.annotation.Resource;
//import java.io.FileReader;
//import java.lang.reflect.Field;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Properties;
//import java.util.Set;
//
//@Component class Car{
////    @Resource // 오른쪽 톱니바퀴에서 프로젝트 스트럭쳐 누른다음. +버튼 -> java -> 톰캣 lib파일 선택 후 확인
//    Engine engine;
//    @Autowired Door door;
////    @Resource Engine engine;
//    // @리소스는 Engine앞에 (name= "engine")이 생략된 것임. 그러면 Engine의 타입이름을 첫글자를 소문자로 바꾼 것을 찾음.
//    // @Autowired 는 맵에서 타입을 찾아서 객체의 참조변수에 자동으로 연결해주는 것
//    // 이제 car.engine = engine;을 쓰지않고 자동으로 연결시켜주면 됨.
//    // @Resource도 있는데 이것은 byName임.(이름으로 찾아서 연결) key("car")를 뒤져서 찾음
//    // @Autowired는 byType임. (타입으로 찾아서 연결) value(주소모음)를 뒤져서 찾음
//
//    @Override
//    public String toString() {
//        return "Car{" +
//                "engine=" + engine +
//                ", door=" + door +
//                '}';
//    }
//}
//@Component class SportsCar extends Car{}
//@Component class Truck extends Car{}
//@Component class Engine{}
//@Component class Door{}
//class AppContext {
//    Map map;
//
//    AppContext() {
//        map = new HashMap();
//        doComponentScan();
//        doAutowired();
//        doResource();
//    }
//
//    private void doResource() {
//        //map에 저장된 객체iv중에 @Resource가 붙어있으면
//        // map에 iv의 이름에 맞는 객체를 찾아서 연결 (객체의 주소를 iv저장)
//        try {
//            for(Object been : map.values()) {
//                for(Field fld : been.getClass().getDeclaredFields()) {
//                    if(fld.getAnnotation(Resource.class)!=null){ // byType이니까 // 종속성추가해줘야함.
//                        fld.set(been, getBean(fld.getName())); // car.engine = obj; 카에 엔진이 있으면 obj넣어주는 것.
//
//                    }
//                }
//            }
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private void doAutowired() {
//        //map에 저장된 객체iv중에 @Autowired가 붙어있으면
//        // map에 iv의 타입에 맞는 객체를 찾아서 연결 (객체의 주소를 iv저장)
//        try {
//            for(Object been : map.values()) {
//                for(Field fld : been.getClass().getDeclaredFields()) {
//                    if(fld.getAnnotation(Autowired.class)!=null){ // byType이니까
//                        fld.set(been, getBean(fld.getType())); // car.engine = obj; 카에 엔진이 있으면 obj넣어주는 것.
//
//                    }
//                }
//            }
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    private void doComponentScan() {
//        // 패키지 내의 클래스 목록을 가져온다
//
//        // 반복문으로 클래스를 하나씩 읽어와서 컴포넌트 이 붙어있는지 확인
//        // 붙어있다면 객체를 생성해서 map에 저장.
//        try {
//            ClassLoader classLoader = AppContext.class.getClassLoader();
//            ClassPath classPath = ClassPath.from(classLoader);
//            Set<ClassPath.ClassInfo> set = classPath.getTopLevelClasses("com.fastcampus.ch3.diCopy4");
//            for(ClassPath.ClassInfo classInfo : set) {
//                Class clazz = classInfo.load();
//                Component component = (Component) clazz.getAnnotation(Component.class);
//                if(component !=null){
//                    String id = StringUtils.uncapitalize(classInfo.getSimpleName());
//                    map.put(id, clazz.newInstance());
//
//                }
//
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
//    }
//    Object getBean(String key) { // byName으로 검색
//        return map.get(key);
//    }
//    Object getBean(Class clazz) { // byType으로 검색
//        for(Object obj : map.values()) {
//            if(clazz.isInstance(obj))
//                return obj;
//        }
//        return null;
//    }
//}
//public class main4 {
//
//    static Object getObject(String key) throws Exception {
//
//        Properties p = new Properties();
//        p.load(new FileReader("config.txt"));
//        Class clazz = Class.forName(p.getProperty(key));
//        return clazz.newInstance();
//    }
//
//    public static void main(String[] args) throws Exception {
//        AppContext ac = new AppContext();
//        Car car =(Car)ac.getBean("car"); // byName으로 객체를 검색
//        Car car2 =(Car)ac.getBean(Car.class); // byType으로 객체를 검색
//
//        Engine engine = (Engine)ac.getBean("engine");
//        Door door = (Door)ac.getBean(Door.class);
//        // 수동으로 객체연결    @Autowired사용 X
////        car.door= door;
////        car.engine = engine;
//        System.out.println("door = " + door);
//        System.out.println("engine = " + engine);
//
//        System.out.println("car = " + car);
//        System.out.println("engine = " + engine);
//    }
////    static Car getCar() throws Exception {
////
////        Properties p = new Properties();
////        p.load(new FileReader("config.txt"));
////        Class clazz = Class.forName(p.getProperty("car"));
////        return (Car)clazz.newInstance();
////    }
//}
//
////		<dependency>
////			<groupId>javax.annotation</groupId>
////			<artifactId>javax.annotation-api</artifactId>
////			<version>1.2</version>
////		</dependency>