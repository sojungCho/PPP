//package com.fastcampus.ch3.diCopy3;
//
//
//import com.google.common.reflect.ClassPath;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StringUtils;
//
//import java.io.FileReader;
//import java.io.IOException;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Properties;
//import java.util.Set;
//
//@Component class Car{
////    @Autowired Engine engine;
//    @Autowired Door door;
////    @Resource Engine engine;
//    // @리소스는 Engine앞에 (name= "engine")이 생략된 것임. 그러면 Engine의 타입이름을 첫글자를 소문자로 바꾼 것을 찾음.
//    // @Autowired 는 맵에서 타입을 찾아서 객체의 참조변수에 자동으로 연결해주는 것
//    // 이제 car.engine = engine;을 쓰지않고 자동으로 연결시켜주면 됨.
//    // @Resource도 있는데 이것은 byName임.(이름으로 찾아서 연결) key("car")를 뒤져서 찾음
//    // @Autowired는 byType임. (타입으로 찾아서 연결) value(주소모음)를 뒤져서 찾음
//
//}
//@Component class SportsCar extends Car{}
//@Component class Truck extends Car{}
//@Component class Engine{}
//@Component class Door{}
//class AppContext {
//    Map map;
//
//    AppContext() {
//        map = new HashMap();
//        doComponentScan();
//    }
//
//    private void doComponentScan() {
//        // 패키지 내의 클래스 목록을 가져온다
//
//        // 반복문으로 클래스를 하나씩 읽어와서 컴포넌트 이 붙어있는지 확인
//        // 붙어있다면 객체를 생성해서 map에 저장.
//        try {
//            ClassLoader classLoader = AppContext.class.getClassLoader();
//            ClassPath classPath = ClassPath.from(classLoader);
//            Set<ClassPath.ClassInfo> set = classPath.getTopLevelClasses("com.fastcampus.ch3.diCopy3");
//            for(ClassPath.ClassInfo classInfo : set) {
//                Class clazz = classInfo.load();
//                Component component = (Component) clazz.getAnnotation(Component.class);
//                if(component !=null){
//                    String id = StringUtils.uncapitalize(classInfo.getSimpleName());
//                    map.put(id, clazz.newInstance());
//
//                }
//
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//
//    }
//    Object getBean(String key) { // byName으로 검색
//        return map.get(key);
//    }
//    Object getBean(Class clazz) { // byType으로 검색
//        for(Object obj : map.values()) {
//            if(clazz.isInstance(obj))
//                return obj;
//        }
//        return null;
//    }
//}
//public class main3 {
//
//    static Object getObject(String key) throws Exception {
//
//        Properties p = new Properties();
//        p.load(new FileReader("config.txt"));
//        Class clazz = Class.forName(p.getProperty(key));
//        return clazz.newInstance();
//    }
//
//    public static void main(String[] args) throws Exception {
//        AppContext ac = new AppContext();
//        Car car =(Car)ac.getBean("car"); // byName으로 객체를 검색
//        Car car2 =(Car)ac.getBean(Car.class); // byType으로 객체를 검색
//        Engine engine = (Engine) ac.getBean("engine");
//        System.out.println("car = " + car);
//        System.out.println("engine = " + engine);
//    }
////    static Car getCar() throws Exception {
////
////        Properties p = new Properties();
////        p.load(new FileReader("config.txt"));
////        Class clazz = Class.forName(p.getProperty("car"));
////        return (Car)clazz.newInstance();
////    }
//}
//
