package com.fastcampus.ch4.domain;

import org.springframework.web.util.UriComponentsBuilder;

import java.util.Objects;

public class SearchCondition {
    private Integer page=1; // 컨트롤러에서 쓸려고 추가해준것.
    private Integer pageSize=10;
//    private Integer offset=0;//얘는 페이지와 페이지 사이즈로 계산되기 떄문에 굳이 저장할 필요 X
    private String keyword ="";
    private String option="";

    public String getQueryString(Integer page) {
        return UriComponentsBuilder.newInstance()
                .queryParam("page", page)
                .queryParam("pageSize", pageSize)
                .queryParam("option", option)
                .queryParam("keyword", keyword)
                .build().toString();
    }
    public String getQueryString() {
        //?page=1&pageSize=10&option=T&keyword="title"
        return getQueryString(page);
    }
    public SearchCondition(){}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SearchCondition that = (SearchCondition) o;
        return Objects.equals(page, that.page) && Objects.equals(pageSize, that.pageSize) && Objects.equals(keyword, that.keyword) && Objects.equals(option, that.option);
    }

    @Override
    public int hashCode() {
        return Objects.hash(page, pageSize, keyword, option);
    }

    // 생성자에서는 offset을 뺌. 왜?
    public SearchCondition(Integer page, Integer pageSize, String keyword, String option) {
        this.page = page;
        this.pageSize = pageSize;
        this.keyword = keyword;
        this.option = option;
    }

    @Override
    public String toString() {
        return "SearchCondition{" +
                "page=" + page +
                ", pageSize=" + pageSize +
                ", offset=" + getOffset() +
                ", keyword='" + keyword + '\'' +
                ", option='" + option + '\'' +
                '}';
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getOffset() {
        return (page-1)*pageSize;
    }



    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getOption() {
        return option;
    }

    public void setOption(String option) {
        this.option = option;
    }
}
